print "Hello world"
